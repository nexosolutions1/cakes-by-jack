// Google Sheets backend for Cakes by Jack — NEW SPREADSHEET (única fonte da verdade).
// Structure: row 1 = headers, row 2+ = data. Plain flat tables.

const GATEWAY = "https://connector-gateway.lovable.dev/google_sheets/v4";
export const SPREADSHEET_ID = "1NYQBaQ9JXnLxm6Gj9z6wqnagHBZadZRx3_VFCXKFCq0";

function gwHeaders() {
  const lovKey = process.env.LOVABLE_API_KEY;
  const connKey = process.env.GOOGLE_SHEETS_API_KEY;
  if (!lovKey || !connKey) throw new Error("Google Sheets connector not configured");
  return {
    Authorization: `Bearer ${lovKey}`,
    "X-Connection-Api-Key": connKey,
    "Content-Type": "application/json",
  };
}

async function gw(path: string, init?: RequestInit) {
  const res = await fetch(`${GATEWAY}${path}`, { ...init, headers: gwHeaders() });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Sheets API ${res.status}: ${text}`);
  }
  return res.json();
}

export function colLetter(n: number) {
  let s = "";
  let x = n;
  while (x > 0) {
    const m = (x - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    x = Math.floor((x - 1) / 26);
  }
  return s;
}

export async function getValues(range: string): Promise<string[][]> {
  const data = await gw(`/spreadsheets/${SPREADSHEET_ID}/values/${range}`);
  return data.values ?? [];
}

export async function setValues(range: string, values: (string | number)[][]) {
  return gw(
    `/spreadsheets/${SPREADSHEET_ID}/values/${range}?valueInputOption=USER_ENTERED`,
    { method: "PUT", body: JSON.stringify({ values }) },
  );
}

export async function getMetadata() {
  return gw(`/spreadsheets/${SPREADSHEET_ID}?fields=sheets.properties.title`);
}

/** Read header row (row 1) + data rows (row 2+) of a tab. */
export async function readTable(tab: string): Promise<{
  headers: string[];
  rows: string[][];
  rowOffset: number;
}> {
  const [headerRows, dataRows] = await Promise.all([
    getValues(`${tab}!A1:Z1`),
    getValues(`${tab}!A2:Z`),
  ]);
  return { headers: headerRows[0] ?? [], rows: dataRows, rowOffset: 2 };
}

export async function findRow(tab: string, idColumn: string, id: string) {
  const { headers, rows, rowOffset } = await readTable(tab);
  const idx = headers.indexOf(idColumn);
  if (idx < 0) return -1;
  const i = rows.findIndex((r) => (r[idx] ?? "") === id);
  return i < 0 ? -1 : rowOffset + i;
}

/** Append a row built from a {header: value} record, aligned to the full header row. */
export async function appendRecord(tab: string, record: Record<string, string | number>) {
  const headerRows = await getValues(`${tab}!A1:Z1`);
  const headers = headerRows[0] ?? [];
  if (headers.length === 0) throw new Error(`Aba "${tab}" sem cabeçalho`);
  const row = headers.map((h) => {
    const v = record[h];
    return v === undefined || v === null ? "" : v;
  });
  const endCol = colLetter(headers.length);
  return gw(
    `/spreadsheets/${SPREADSHEET_ID}/values/${tab}!A1:${endCol}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
    { method: "POST", body: JSON.stringify({ values: [row] }) },
  );
}

/** Update only the specified cells in a row, leaving other columns untouched. */
export async function updateRecord(
  tab: string,
  rowNumber: number,
  patch: Record<string, string | number>,
) {
  const headerRows = await getValues(`${tab}!A1:Z1`);
  const headers = headerRows[0] ?? [];
  const data: { range: string; values: (string | number)[][] }[] = [];
  for (const [key, val] of Object.entries(patch)) {
    const idx = headers.indexOf(key);
    if (idx < 0) continue;
    data.push({
      range: `${tab}!${colLetter(idx + 1)}${rowNumber}`,
      values: [[val ?? ""]],
    });
  }
  if (data.length === 0) return null;
  return gw(`/spreadsheets/${SPREADSHEET_ID}/values:batchUpdate`, {
    method: "POST",
    body: JSON.stringify({ valueInputOption: "USER_ENTERED", data }),
  });
}
