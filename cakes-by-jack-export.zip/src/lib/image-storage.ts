// Client-side helper to upload product photos.
// Uploads/deletes go through an authenticated server route that uses
// the service-role key on the server. The "catalog-images" bucket itself
// denies all public writes — the client never talks to Supabase Storage
// directly for writes. Reads stream through /api/public/catalog-image/.

const SESSION_KEY = "cbj.session.whatsapp";

function sessionWhatsapp(): string {
  try {
    return localStorage.getItem(SESSION_KEY) ?? "";
  } catch {
    return "";
  }
}

export function publicImageUrl(path: string): string {
  if (!path) return "";
  if (path.startsWith("http://") || path.startsWith("https://")) return path;
  return `/api/public/catalog-image/${path}`;
}

export async function uploadProductImage(file: File): Promise<string> {
  const form = new FormData();
  form.append("file", file);
  const res = await fetch("/api/public/catalog-image-upload", {
    method: "POST",
    headers: { "x-cbj-whatsapp": sessionWhatsapp() },
    body: form,
  });
  if (!res.ok) {
    const msg = await res.text().catch(() => "");
    throw new Error(`Falha no upload: ${msg || res.status}`);
  }
  const data = (await res.json()) as { path: string };
  return data.path;
}

export async function deleteProductImage(path: string): Promise<void> {
  if (!path || path.startsWith("http")) return;
  await fetch("/api/public/catalog-image-upload", {
    method: "DELETE",
    headers: {
      "x-cbj-whatsapp": sessionWhatsapp(),
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ path }),
  });
}
