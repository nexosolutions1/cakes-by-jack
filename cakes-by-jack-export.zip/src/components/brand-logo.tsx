import logo from "@/assets/cakes-by-jack-logo.png.asset.json";

export function BrandLogo({ size = 40, className = "" }: { size?: number; className?: string }) {
  return (
    <img
      src={logo.url}
      alt="Cakes by Jack"
      width={size}
      height={size}
      className={`rounded-full object-cover ring-2 ring-rose-soft/60 ${className}`}
    />
  );
}
