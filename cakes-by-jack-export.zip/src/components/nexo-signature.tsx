import { Sparkles } from "lucide-react";

/**
 * Assinatura discreta da Nexo Solutions.
 * Aparece no rodapé da sidebar e no card de login.
 */
export function NexoSignature({
  variant = "sidebar",
}: {
  variant?: "sidebar" | "inline";
}) {
  if (variant === "inline") {
    return (
      <div className="mt-6 flex items-center justify-center gap-1.5 text-[10px] uppercase tracking-[0.28em] text-muted-foreground/70">
        <Sparkles className="h-2.5 w-2.5" />
        <span>by Nexo Solutions</span>
      </div>
    );
  }
  return (
    <div className="flex items-center justify-center gap-1.5 border-t border-sidebar-border px-3 py-3 text-[10px] font-medium uppercase tracking-[0.22em] text-sidebar-foreground/55 group-data-[collapsible=icon]:hidden">
      <Sparkles className="h-2.5 w-2.5" />
      <span>by Nexo Solutions</span>
    </div>
  );
}
